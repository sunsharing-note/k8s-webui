import axios from 'axios';

let base = '';

let instance = axios.create({ headers: {'content-type': 'application/x-www-form-urlencoded'} });

export const requestLogin = params => { return axios.post(`${base}/login`, params).then(res => res.data); };

export const getUserList = params => { return axios.get(`${base}/user/list`, { params: params }); };

export const getUserListPage = params => { return axios.get(`${base}/user/listpage`, { params: params }); };

export const removeUser = params => { return axios.get(`${base}/user/remove`, { params: params }); };

export const batchRemoveUser = params => { return axios.get(`${base}/user/batchremove`, { params: params }); };

export const editUser = params => { return axios.get(`${base}/user/edit`, { params: params }); };

export const addUser = params => { return axios.get(`${base}/user/add`, { params: params }); };

export const getClusterInfo = params => { return instance.get('/api/nodes?page='+params.page);};

export const getNamespace = params => { return instance.get('/api/namespace');};

export const getPodsInfo = params => { return instance.get('/api/pods?page='+params.page);};

export const getPvsInfo = params => { return instance.get('/api/pvs?page='+params.page);};

export const getPvcsInfo = params => { return instance.get('/api/pvcs?page='+params.page);};

export const getSvcsInfo = params => { return instance.get('/api/svcs?page='+params.page);};

export const getPodCnt = params => { return instance.get('/api/pod_count');};
export const getNodCnt = params => { return instance.get('/api/node_count');};
export const getPvCnt = params => { return instance.get('/api/pv_count');};
export const getPvcCnt = params => { return instance.get('/api/pvc_count');};
export const getSvcCnt = params => { return instance.get('/api/svc_count');};

export const searchInfo = params => { return instance.get('/api/query?obj='+params.obj+'&namespace='+params.namespace+'&page='+params.page);};
export const searchCnt = params => { return instance.get('/api/query_count?obj='+params.obj+'&namespace='+params.namespace);};

export const refreshInfo = params => { return instance.get('/api/refresh?obj='+params.obj);};