<template>
    <section style="margin-top:30px">
        <el-form ref="form">
            <el-col :span="9">
                <el-form-item label="资源对象">
                    <el-select v-model="form.region" placeholder="请选择资源对象" @change="changeHandle()">
                        <el-option label="pod" value="pod"></el-option>
                        <el-option label="node" value="node"></el-option>
						<el-option label="pv" value="pv"></el-option>
						<el-option label="pvc" value="pvc"></el-option>
						<el-option label="service" value="service"></el-option>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="9">
                <el-form-item label="namespace">
                    <el-select v-model="form.namespace" :disabled="enableNamspace" placeholder="请选择namespace">
                        <el-option
							v-for="item in namespaceArr"
							:key="item.value"
							:label="item.label"
							:value="item.value">
						</el-option>
                    </el-select>
                </el-form-item>
            </el-col>
            <el-col :span="6">
                <el-form-item>
                    <el-button type="primary" @click="search(1)">搜索</el-button>
                    <el-button type="reset" @click="reset()">重置</el-button>
					<el-button type="info" @click="refresh()" v-loading.fullscreen.lock="fullscreenLoading">刷新</el-button>
                </el-form-item>
            </el-col>
        </el-form>

        <!--列表-->
		<el-table :data="users" v-loading="listLoading" highlight-current-row style="width: 100%;">
			<el-table-column type="selection" width="55">
			</el-table-column>

			<el-table-column v-for="(col,index) in cols" :prop="col.prop" :label="col.label" :width="col.width" sortable></el-table-column>
						
			<el-table-column label="操作" width="200" align="center">
				<template slot-scope="scope">
					<span v-if="form.region=='node'">
						<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>
						<el-button size="small" @click="handleUnDispather(scope.$index, scope.row)">不可调度</el-button>
					</span>
					<span v-else-if="form.region=='pv' || form.region=='pvc' || form.region=='service'">
						<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>
						<!-- <el-button size="small" @click="handleReadDes(scope.$index, scope.row)">查看描述</el-button> -->
					</span>
					<span v-else>
						<el-button type="danger" size="small" @click="handleDel(scope.$index, scope.row)">删除</el-button>
						<el-button size="small" @click="handleLogRead(scope.$index, scope.row)">日志查看</el-button>
					</span>
				</template>
			</el-table-column>
			
		</el-table>
		<!--工具条-->
		<el-col :span="24" class="toolbar">
			<el-pagination layout="total,prev, pager, next" @current-change="handleCurrentChange" :pager-count="5" :page-size="pageSize" :total="total" style="float:right;">
			</el-pagination>
		</el-col>
    </section>
</template>
<script>
    import util from '../../common/js/util'
	//import NProgress from 'nprogress'
	import { getUserListPage, removeUser, batchRemoveUser, editUser, addUser, getClusterInfo, getNamespace,
		getPodsInfo, getPvsInfo, getPodCnt, getNodCnt, getPvCnt, getPvcsInfo, getPvcCnt, getSvcsInfo, getSvcCnt,
		searchInfo, searchCnt, refreshInfo
	} from '../../api/api';
	export default {
		data() {
			return {
				form: {
					region: 'node',
					namespace:''
                },
                filters: {
					name: ''
				},
				cols:[],
				namespaceArr:[],
                users: [],
                listLoading: false,
                total: 0,
				page: 1,
				pageSize:5,
				enableNamspace:true,
				fullscreenLoading: false
			}
		},
		methods: {
			reset(){
				this.form.region = '';
				this.form.namespace = '';
			},
			handleCurrentChange(val) {
				this.page = val;
				this.changeHandle();
			},
			//不可调度
			handleUnDispather(index,row){
				console.log(index);
				console.log(row);

			},
			//日志查看
			handleLogRead(index,row){

			},
			//查看描述
			handleReadDes(index,row){

			},
            //集群信息
			getUsers() {
				this.cols=[{prop:'id',label:'ID',width:'60'},{prop:'name',label:'NAME',width:'150'},{prop:'role',label:'ROLE',width:'150'},{prop:'version',label:'VERSION',width:'120'},{prop:'status',label:'STATUS',width:'120'}];
				let para = {
					page: this.page
				};

				getNodCnt().then(res => {
					this.total = res.data;
				});

				getClusterInfo(para).then((res) => {
					//this.total = res.data.length;
					let nodeArr = [];
					// let start = (this.page-1)*this.pageSize;
					// let end = this.page*this.pageSize;
					// if(end>=this.total){
					// 	end = this.total;
					// }
					let obj = {};
					for(let i=0;i<res.data.length;i++){
						obj = res.data[i].fields;
						obj.id = res.data[i].pk;
						nodeArr.push(obj);
					}

					this.users = nodeArr;
					this.listLoading = false;
				});

				// getUserListPage(para).then((res) => {
				// 	console.log(res.data)
				// 	this.total = res.data.total;
				// 	this.users = res.data.users;
				// 	this.listLoading = false;
				// });

				this.listLoading = true;
			},
			getPos(){
				this.cols=[{prop:'id',label:'ID',width:'60'},{prop:'name',label:'name',width:'300'},{prop:'ip',label:'ip',width:'120'},{prop:'namespace',label:'namespace',width:'150'},{prop:'status',label:'status',width:'120'}];
				let para = {
					page: this.page
				};

				getPodCnt().then(res => {
					this.total = res.data;
				});

				getPodsInfo(para).then((res) => {
					//this.total = res.data.length;
					let podArr = [];
					// let start = (this.page-1)*this.pageSize;
					// let end = this.page*this.pageSize;
					// if(end>this.total){
					// 	end = this.total-1;
					// }
					let podObj = {};
					for(let i=0;i<res.data.length;i++){
						podObj = res.data[i].fields;
						podObj.id = res.data[i].pk;
						podArr.push(podObj);
					}
					this.users = podArr;
					this.listLoading = false;
				});

				this.listLoading = true;
			},
			getPvs(){
				this.cols=[/*{prop:'id',label:'ID',width:'60'},*/
				{prop:'name',label:'name',width:'150'},{prop:'capacity',label:'capacity',width:'120'},
				{prop:'access_modes',label:'access_modes',width:'150'},
				{prop:'persistent_volume_reclaim_policy',label:'reclaim_policy',width:'150'},
				{prop:'status',label:'status',width:'100'},
				{prop:'storage_class_name',label:'class_name',width:'130'}];
				let para = {
					page: this.page
				};

				getPvCnt().then(res => {
					this.total = res.data;
				});

				getPvsInfo(para).then((res) => {
					let pvArr = [];
					// let start = (this.page-1)*this.pageSize;
					// let end = this.page*this.pageSize;
					// if(end>this.total){
					// 	end = this.total-1;
					// }
					let obj = {};
					for(let i=0;i<res.data.length;i++){
						obj = res.data[i].fields;
						obj.id = res.data[i].pk;
						pvArr.push(obj);
					}
					this.users = pvArr;
					this.listLoading = false;
				});

				this.listLoading = true;
			},
			getPvcs(){
				this.cols=[/*{prop:'id',label:'ID',width:'60'},*/
				{prop:'name',label:'name',width:'150'},
				{prop:'capacity',label:'capacity',width:'120'},
				{prop:'access_mode',label:'access_mode',width:'150'},
				{prop:'phase',label:'phase',width:'150'},
				{prop:'namespace',label:'namespace',width:'150'},
				{prop:'storage_class_name',label:'class_name',width:'150'}];
				let para = {
					page: this.page
				};

				getPvcCnt().then(res => {
					this.total = res.data;
				});

				getPvcsInfo(para).then((res) => {
					let pvcArr = [];
					// let start = (this.page-1)*this.pageSize;
					// let end = this.page*this.pageSize;
					// if(end>this.total){
					// 	end = this.total-1;
					// }
					let obj = {};
					for(let i=0;i<res.data.length;i++){
						obj = res.data[i].fields;
						obj.id = res.data[i].pk;
						pvcArr.push(obj);
					}
					this.users = pvcArr;
					this.listLoading = false;
				});

				this.listLoading = true;
			},
			getSvcs(){
				this.cols=[{prop:'id',label:'ID',width:'60'},
				{prop:'name',label:'name',width:'150'},
				{prop:'namespace',label:'namespace',width:'150'},
				{prop:'cluster_ip',label:'cluster_ip',width:'120'},
				{prop:'node_port',label:'node_port',width:'120'},
				{prop:'port',label:'port',width:'100'}];
				let para = {
					page: this.page
				};

				getSvcCnt().then(res => {
					this.total = res.data;
				});

				getSvcsInfo(para).then((res) => {
					let svcArr = [];
					// let start = (this.page-1)*this.pageSize;
					// let end = this.page*this.pageSize;
					// if(end>this.total){
					// 	end = this.total-1;
					// }
					let obj = {};
					for(let i=0;i<res.data.length;i++){
						obj = res.data[i].fields;
						obj.id = res.data[i].pk;
						svcArr.push(obj);
					}
					this.users = svcArr;
					this.listLoading = false;
				});

				this.listLoading = true;
			},
			getNameSpaceInfo(){
				getNamespace().then(res => {
					let data = res.data;
					let obj;
					for(let i=0;i<data.length;i++){
						obj = {};
						obj.label=data[i].fields.name;
						obj.value=data[i].fields.name;
						this.namespaceArr.push(obj);
					}
					
				});
			},
			//删除
			handleDel(index,row){

			},
			changeHandle(){
				if(this.form.region==='pod'){
					this.enableNamspace = false;
					if(this.form.namespace!=''){
						this.search(this.page);
					}else{
						this.getPos();
					}
				} else if(this.form.region==='pv'){
					this.form.namespace = '';
					this.enableNamspace = true;
					this.getPvs();
				}else if(this.form.region==='node'){
					this.form.namespace = '';
					this.enableNamspace = true;
					this.getUsers();
				}else if(this.form.region==='pvc'){
					this.enableNamspace = false;
					if(this.form.namespace!=''){
						this.search(this.page);
					}else{
						this.getPvcs();
					}
				}else{
					this.enableNamspace = false;
					if(this.form.namespace!=''){
						this.search(this.page);
					}else{
						this.getSvcs();
					}
				}
			},
			refresh(){
				let para = {
					obj: this.form.region
				};
				this.fullscreenLoading = true;
				//setTimeout(() => {
					refreshInfo(para).then(res => {
						this.fullscreenLoading = false;
						if(res.data==='True'){
							this.$message({
								message: '刷新成功',
								type: 'success'
							});
						} else{
							this.$message.error('刷新失败');
						}
					});
					
				//}, 2000);
				//this.$message.error('刷新超时,请稍后在试');
			},
			search(page){
				let para = {
					obj: this.form.region,
					namespace: this.form.namespace,
					page: page
				};
				searchCnt(para).then(res => {
					this.total = res.data;
				});
				searchInfo(para).then(res => {
					if(this.form.region==='pod'){
						this.enableNamspace = false;
						this.cols=[{prop:'id',label:'ID',width:'60'},
							{prop:'name',label:'name',width:'300'},
							{prop:'ip',label:'ip',width:'120'},
							{prop:'namespace',label:'namespace',width:'150'},
							{prop:'status',label:'status',width:'120'}];
						
					} else if(this.form.region==='pvc'){
						this.cols=[/*{prop:'id',label:'ID',width:'60'},*/
							{prop:'name',label:'name',width:'150'},
							{prop:'capacity',label:'capacity',width:'120'},
							{prop:'access_mode',label:'access_mode',width:'150'},
							{prop:'phase',label:'phase',width:'150'},
							{prop:'namespace',label:'namespace',width:'150'},
							{prop:'storage_class_name',label:'class_name',width:'150'}];
					} else{//service
						this.cols=[{prop:'id',label:'ID',width:'60'},
							{prop:'name',label:'name',width:'150'},
							{prop:'namespace',label:'namespace',width:'150'},
							{prop:'cluster_ip',label:'cluster_ip',width:'120'},
							{prop:'node_port',label:'node_port',width:'120'},
							{prop:'port',label:'port',width:'100'}];
					}
					let dataArr = [];
					let obj = {};
					for(let i=0;i<res.data.length;i++){
						obj = res.data[i].fields;
						obj.id = res.data[i].pk;
						dataArr.push(obj);
					}
					this.users = dataArr;
					this.listLoading = false;
				});
				this.listLoading = true;
			}
        },
        mounted() {
			this.getUsers();
			this.getNameSpaceInfo();
		}
	}

</script>