<template>
  <el-tabs v-model="activeName" @tab-click="handleClick">
    <el-tab-pane label="从文本输入框创建" name="first">
		<el-input
			type="textarea"
			:autosize="{ minRows: 2, maxRows: 10}"
			placeholder="请输入内容"
			v-model="textarea">
		</el-input>
	</el-tab-pane>
    <el-tab-pane label="从文件创建" name="second">
		<el-upload
			class="upload-demo"
			drag
			action="https://jsonplaceholder.typicode.com/posts/"
			multiple>
			<i class="el-icon-upload"></i>
			<div class="el-upload__text">将文件拖到此处，或<em>点击上传</em></div>
			<div class="el-upload__tip" slot="tip">只能上传YAML或JSON文件，且不超过500kb</div>
		</el-upload>
	</el-tab-pane>
    <el-tab-pane label="创建应用" name="third">角色管理</el-tab-pane>
  </el-tabs>
</template>
<script>
  export default {
    data() {
      return {
		  textarea:'',
          activeName: 'second'
      };
    },
    methods: {
      handleClick(tab, event) {
        console.log(tab, event);
      }
    }
  };
</script>